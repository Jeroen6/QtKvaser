var NAVTREE =
[
  [ "Kvaser CANLIB", "index.html", [
    [ "Welcome to Kvaser CANLIB!", "index.html", [
      [ "Help File Overview", "page_help_file_overview.html", null ],
      [ "License and Copyright", "page_license_and_copyright.html", null ],
      [ "CANLIB API Calls Grouped by Function", "page_canlib_api_calls_grouped_by_function.html", null ],
      [ "CANLIB Core API Calls", "page_core_api_calls.html", null ]
    ] ],
    [ "Related Pages", "pages.html", [
      [ "Porting Code", "page_porting_code.html", [
        [ "Porting Code Introduction", "page_porting_code_intro.html", null ],
        [ "Porting from other APIs", "page_porting_code_other.html", null ],
        [ "Porting from older CANLIB APIs", "page_porting_code_older.html", null ]
      ] ],
      [ "User's Guide", "page_user_guide.html", [
        [ "Introduction", "page_user_guide_intro.html", [
          [ "What is CANLIB?", "page_user_guide_intro_what.html", null ],
          [ "Hello, CAN!", "page_user_guide_intro_hello.html", null ],
          [ "Programmer's Overview", "page_user_guide_intro_programmers.html", null ]
        ] ],
        [ "Initialization", "page_user_guide_init.html", [
          [ "Library Initialization", "page_user_guide_init_lib_init.html", null ],
          [ "Library Deinitialization and Cleanup", "page_user_guide_init_lib_deinit.html", null ],
          [ "Chips and Channels", "page_user_guide_init_sel_channel.html", null ],
          [ "Bit Rate and Other Bus Parameters", "page_user_guide_init_bit_rate.html", null ],
          [ "CAN Driver Modes", "page_user_guide_init_driver_modes.html", null ]
        ] ],
        [ "Sending and Receiving", "page_user_guide_send_recv.html", [
          [ "Bus On / Bus Off", "page_user_guide_send_recv_bus_on_off.html", null ],
          [ "Reading Messages", "page_user_guide_send_recv_reading.html", null ],
          [ "Sending Messages", "page_user_guide_send_recv_sending.html", null ],
          [ "Asynchronous Notification", "page_user_guide_send_recv_asynch_not.html", null ],
          [ "Message Filters", "page_user_guide_send_recv_filters.html", null ],
          [ "Message Mailboxes", "page_user_guide_send_recv_mailboxes.html", null ],
          [ "Overruns", "page_user_guide_send_recv_overruns.html", null ],
          [ "Message Queue and Buffer Sizes", "page_user_guide_send_recv_queue_and_buf_sizes.html", null ],
          [ "Object Buffers", "page_user_guide_send_recv_obj_buf.html", null ],
          [ "Different CAN Frame Types", "page_user_guide_send_recv_sending_different_types.html", null ]
        ] ],
        [ "Handling Bus Errors", "page_user_guide_bus_errors.html", [
          [ "Handling Bus Errors", "page_user_guide_bus_errors_error_frames.html", null ],
          [ "SJA1000 Error Codes", "page_user_guide_bus_errors_sja1000_error_codes.html", null ]
        ] ],
        [ "Using Threads", "page_user_guide_threads.html", [
          [ "Threaded Applications", "page_user_guide_threads_applications.html", null ]
        ] ],
        [ "Getting and Setting Device Information", "page_user_guide_dev_info.html", [
          [ "Obtaining special information", "page_user_guide_dev_info_special.html", null ],
          [ "Obtaining Status Information", "page_user_guide_dev_info_status.html", null ]
        ] ],
        [ "Virtual Channels", "page_user_guide_virtual.html", [
          [ "Virtual Channels", "page_user_guide_virtual_info.html", null ]
        ] ],
        [ "Time Measurement", "page_user_guide_time.html", [
          [ "Time Measurement", "page_user_guide_time_general.html", null ],
          [ "Time Stamping Accuracy and Resolution", "page_user_guide_time_accuracy_and_resolution.html", null ]
        ] ],
        [ "Compiling, Linking and Installing", "page_user_guide_build.html", [
          [ "Debugging Techniques", "page_user_guide_build_debugging.html", null ],
          [ "Deploying Your Application", "page_user_guide_build_deploying.html", null ],
          [ "Driver Installation", "page_user_guide_build_installation.html", null ],
          [ "Version Checking", "page_user_guide_build_driver_version.html", null ],
          [ "Compiling and Linking Your Code", "page_user_guide_build_campiling_linking.html", null ]
        ] ],
        [ "LIN", "page_user_guide_lin.html", [
          [ "Using the LIN Bus", "page_user_guide_lin_intro.html", null ],
          [ "Accessing the Databases", "page_user_guide_lin_candb.html", null ]
        ] ],
        [ "Frequently Asked Questions", "page_user_guide_faq.html", null ],
        [ "Support", "page_user_guide_support.html", null ],
        [ "Miscellaneous Topics", "page_user_guide_misc.html", [
          [ "Named Parameter Sets", "page_user_guide_misc_named_parameters.html", null ],
          [ "Message Flags", "page_user_guide_misc_message_flags.html", null ],
          [ "Bit Rate Constants", "page_user_guide_misc_bitrate.html", null ],
          [ "Code and Mask Format", "page_user_guide_misc_code_and_mask.html", null ]
        ] ]
      ] ],
      [ "Code snippets", "page_code_snippets.html", [
        [ "Code Examples", "page_code_snippets_examples.html", null ],
        [ "Bit Rate Examples", "page_code_snippets_bit_rate.html", null ]
      ] ],
      [ "Hardware Specific Notes", "page_hardware_specific.html", [
        [ "CAN Controller Specific Notes", "page_hardware_specific_can_controllers.html", null ]
      ] ]
    ] ],
    [ "Modules", "modules.html", [
      [ "General", "group___general.html", [
        [ "Functions", "group___general.html", [
          [ "canGetChannelData", "group___general.html#gab9552d1a588b0dbc144b097acba017b2", null ],
          [ "canGetErrorText", "group___general.html#ga01a7a415c95c579750bcdd95a1d245c4", null ],
          [ "canGetNumberOfChannels", "group___general.html#ga65169ca633cd30aa92b8a80e28a5378b", null ],
          [ "canGetVersion", "group___general.html#gafb5688859c56ecb6f8d85705d3ec2f14", null ],
          [ "canInitializeLibrary", "group___general.html#gaff1ec1d3416d3bdd56336a7b9ac008b1", null ],
          [ "canIoCtl", "group___general.html#gacef9be3499b47381587121437d9386ba", null ],
          [ "canProbeVersion", "group___general.html#ga46ad377f3ba942018cb2af0c3f9dc69f", null ],
          [ "canUnloadLibrary", "group___general.html#ga0d1c0e54ea20c3e3b328a32eb10c7b47", null ],
          [ "kvAnnounceIdentity", "group___general.html#ga34fd728cb74a138a111048dab6b21ad1", null ],
          [ "kvAnnounceIdentityEx", "group___general.html#gae2492f4a747f52a5c0a89ba478dbd504", null ],
          [ "kvBeep", "group___general.html#ga57cec532a312566eee6f8dbd2b55c2d5", null ],
          [ "kvDeviceGetMode", "group___general.html#ga0cc562aa5ce1418b8c207c9f95976a25", null ],
          [ "kvDeviceSetMode", "group___general.html#ga6d0d64f2700b28995af6adf8ef024276", null ],
          [ "kvFlashLeds", "group___general.html#ga5e693931a45934fdfef3e36e8445feb7", null ],
          [ "kvGetApplicationMapping", "group___general.html#gabe931cc9a89943fa43a73c7c543a6350", null ],
          [ "kvGetSupportedInterfaceInfo", "group___general.html#ga76cb21c1b104f9b679caa3f4cda7424d", null ],
          [ "kvPingGetLatest", "group___general.html#ga6282f3c8acc827bda9346f62458ad184", null ],
          [ "kvPingRequest", "group___general.html#ga3d079cd4a14d815c57c9a1c47a575afa", null ],
          [ "kvReadDeviceCustomerData", "group___general.html#gac44b14b55ee7cd11545625a98e2a9987", null ],
          [ "kvReadTimer", "group___general.html#ga81d6e5302dee3d7b06fbcba0caed903d", null ],
          [ "kvReadTimer64", "group___general.html#ga593ed46a3b806062aece4be96ddb70aa", null ],
          [ "kvSelfTest", "group___general.html#ga4af68fc4f4c0be811c7396d98332c1ed", null ],
          [ "kvSetNotifyCallback", "group___general.html#gac9046767fa5065bc4acd42c7b2427524", null ]
        ] ]
      ] ],
      [ "CAN", "group___c_a_n.html", [
        [ "Typedefs", "group___c_a_n.html", [
          [ "canBusStatistics", "group___c_a_n.html#ga2bb3bba2f57c8222ace214f3f005c39c", null ]
        ] ],
        [ "Functions", "group___c_a_n.html", [
          [ "canAccept", "group___c_a_n.html#gaef67673ce150f26ada39fc376182ce4e", null ],
          [ "canBusOff", "group___c_a_n.html#ga35478fd54d6e830555c85492c9ab2f80", null ],
          [ "canBusOn", "group___c_a_n.html#gab84fce54d4b2c57df9681d452c6319c4", null ],
          [ "canClose", "group___c_a_n.html#ga56459e39593096dac3a6723493f5e898", null ],
          [ "canFdSecondarySamplePoint", "group___c_a_n.html#ga5126531eb755c8361de650bcc3b80123", null ],
          [ "canFlushReceiveQueue", "group___c_a_n.html#ga851de5019c368369c385d5a565b74acf", null ],
          [ "canFlushTransmitQueue", "group___c_a_n.html#gaf2f4378bca14c7006e1fa3a6b82056cc", null ],
          [ "canGetBusOutputControl", "group___c_a_n.html#ga07dd7b9e8b4e694d2eba088a53cf61fa", null ],
          [ "canGetBusParams", "group___c_a_n.html#ga5e65e95a774560f689b786a8bea603c0", null ],
          [ "canGetBusParamsFd", "group___c_a_n.html#ga39b0dfb28f0a20129149ee468e0a06f2", null ],
          [ "canGetBusStatistics", "group___c_a_n.html#gafa662909bccb523b748e1e73e8c79c6b", null ],
          [ "canGetDriverMode", "group___c_a_n.html#ga8f257e126d694b78c892851a710123e6", null ],
          [ "canGetHandleData", "group___c_a_n.html#ga7fbd27e06d20e73a4bdf0ff5eeaf74d8", null ],
          [ "canOpenChannel", "group___c_a_n.html#gaf4e7a8053f90cf57a3658e485b1aaefa", null ],
          [ "canRead", "group___c_a_n.html#ga46e62517c7a4bcf7d5f96aa7d9f56684", null ],
          [ "canReadErrorCounters", "group___c_a_n.html#ga9e941196bed56bc5377028010e186048", null ],
          [ "canReadSpecific", "group___c_a_n.html#gafd7959466ef9ac6aa192943b495c77ae", null ],
          [ "canReadSpecificSkip", "group___c_a_n.html#ga9b18afbe9d650f23690585860302e538", null ],
          [ "canReadStatus", "group___c_a_n.html#ga9b4d086b02b348114847c0a8ee67c971", null ],
          [ "canReadSync", "group___c_a_n.html#ga74ca2ea073da8b24ec0856dce837fe8c", null ],
          [ "canReadSyncSpecific", "group___c_a_n.html#gab51efe7c6c69f95a47c4cd9bc0c1394d", null ],
          [ "canReadTimer", "group___c_a_n.html#ga75e328cd3f597881286e746d978e4b7b", null ],
          [ "canReadWait", "group___c_a_n.html#ga2edd785a87cc16b49ece8969cad71e5b", null ],
          [ "canRequestBusStatistics", "group___c_a_n.html#ga743cff980bcfa31b3fa8716426362bfb", null ],
          [ "canRequestChipStatus", "group___c_a_n.html#ga12a364d6f9aaed73ad158903b077e844", null ],
          [ "canResetBus", "group___c_a_n.html#ga84182e71cfeae3608a6a47a0bcc2faa2", null ],
          [ "canSetAcceptanceFilter", "group___c_a_n.html#gab0c7c4b4949146d131c8a0afd6097901", null ],
          [ "canSetBitrate", "group___c_a_n.html#gaf93a0dfe011414584aecebfa5d9003f6", null ],
          [ "canSetBusOutputControl", "group___c_a_n.html#gae6a5b10df2516909004177a9330a7dc8", null ],
          [ "canSetBusParams", "group___c_a_n.html#ga14575bf23bf18918c0286e072e3c11cc", null ],
          [ "canSetBusParamsC200", "group___c_a_n.html#ga3298a897471c41bd34ec5c11a664c8fb", null ],
          [ "canSetBusParamsFd", "group___c_a_n.html#ga53a1e4b627ac0d5009c8961adef191f7", null ],
          [ "canSetDriverMode", "group___c_a_n.html#ga158f8a04cea7ae7ec19856147474499c", null ],
          [ "canSetNotify", "group___c_a_n.html#ga7d2b3b2381f355b0fa4a0a561068bcdb", null ],
          [ "canTranslateBaud", "group___c_a_n.html#gaf38b95fce4930347d9986887ec046e13", null ],
          [ "canWrite", "group___c_a_n.html#ga30a6dda4b300294c2e549186c992b44a", null ],
          [ "canWriteSync", "group___c_a_n.html#ga4eb2c1537a14150d34f5fdc99f09f535", null ],
          [ "canWriteWait", "group___c_a_n.html#ga3cc800578cb33d6aa490d0ccad0b8fff", null ]
        ] ],
        [ "Data Structures", "group___c_a_n.html", [
          [ "canBusStatistics_s", "structcan_bus_statistics__s.html", null ]
        ] ]
      ] ],
      [ "Object buffers", "group___object_buffers.html", [
        [ "Functions", "group___object_buffers.html", [
          [ "canObjBufAllocate", "group___object_buffers.html#gacfd23956af809dfc6db822c2f5ba25e7", null ],
          [ "canObjBufDisable", "group___object_buffers.html#gaeb6e506db100de24d556ab65c2fcb593", null ],
          [ "canObjBufEnable", "group___object_buffers.html#ga3e145ec233501345db191ae715a09cb4", null ],
          [ "canObjBufFree", "group___object_buffers.html#ga2a7e7c895e41b20da47aa850712d264a", null ],
          [ "canObjBufFreeAll", "group___object_buffers.html#gaf836ebe16681215a3a40defa3a9d81ad", null ],
          [ "canObjBufSendBurst", "group___object_buffers.html#ga8385ea3d2278fb45cf2a11042940b92b", null ],
          [ "canObjBufSetFilter", "group___object_buffers.html#ga16a648123fbc05b8c4a2a46d7d7e1c2c", null ],
          [ "canObjBufSetFlags", "group___object_buffers.html#ga802fdc1accf0124b0b442623c6668f41", null ],
          [ "canObjBufSetMsgCount", "group___object_buffers.html#gaab0389f48769a91f540d2b97e8fd031b", null ],
          [ "canObjBufSetPeriod", "group___object_buffers.html#ga9285a2316c11bc17ec2a98ab64812ce5", null ],
          [ "canObjBufWrite", "group___object_buffers.html#ga9b0e3dffd54e5abdd6972dd468353022", null ]
        ] ]
      ] ],
      [ "Time Domain Handling", "group___time_domain_handling.html", [
        [ "Typedefs", "group___time_domain_handling.html", [
          [ "kvTimeDomainData", "group___time_domain_handling.html#gae1de7dc5611333ad82c8e2bb586135ab", null ]
        ] ],
        [ "Functions", "group___time_domain_handling.html", [
          [ "kvTimeDomainAddHandle", "group___time_domain_handling.html#ga7db84bcaf7a2163298e3b318748ccb41", null ],
          [ "kvTimeDomainCreate", "group___time_domain_handling.html#gaef2b34a7cd8ab01fc140aabe3a5f5539", null ],
          [ "kvTimeDomainDelete", "group___time_domain_handling.html#gaf42198d9685ffc7094fc4cd276ab1976", null ],
          [ "kvTimeDomainGetData", "group___time_domain_handling.html#gafab02cbe0c7fd8cfa65382d492d724b9", null ],
          [ "kvTimeDomainRemoveHandle", "group___time_domain_handling.html#ga71f7890c6b77e80de99a3c9416cacf24", null ],
          [ "kvTimeDomainResetTime", "group___time_domain_handling.html#gaf1857d6195e783c082b44a6e6cf9f745", null ]
        ] ],
        [ "Data Structures", "group___time_domain_handling.html", [
          [ "kvTimeDomainData_s", "structkv_time_domain_data__s.html", null ]
        ] ]
      ] ],
      [ "Named Parameter Settings", "group___named_parameter_settings.html", [
        [ "Functions", "group___named_parameter_settings.html", [
          [ "canParamCommitChanges", "group___named_parameter_settings.html#ga13c706cfc1d2c1931c5be0dd6f8644a4", null ],
          [ "canParamCreateNewEntry", "group___named_parameter_settings.html#ga32f6a473bdab40c8bf971a5d80beedd2", null ],
          [ "canParamDeleteEntry", "group___named_parameter_settings.html#ga85d196e14288ad14e614d1d293afcd32", null ],
          [ "canParamFindByName", "group___named_parameter_settings.html#ga91886cded87a59bf550cb6697bf5a45e", null ],
          [ "canParamGetBusParams", "group___named_parameter_settings.html#ga7f8bd035f474d325b904451f6575d2c2", null ],
          [ "canParamGetChannelNumber", "group___named_parameter_settings.html#gae6641f5c024ad0356ed535d5070c21c8", null ],
          [ "canParamGetCount", "group___named_parameter_settings.html#ga9df755f19415d207fe39ddf7df05a8b2", null ],
          [ "canParamGetName", "group___named_parameter_settings.html#gabce99362019fec8fd7062a567d9e42a8", null ],
          [ "canParamSetBusParams", "group___named_parameter_settings.html#ga7ef8f8128ca946e03a1bd3e17e9315fb", null ],
          [ "canParamSetChannelNumber", "group___named_parameter_settings.html#ga97cc06366f6a918fe864ab59f0fcb2b0", null ],
          [ "canParamSetName", "group___named_parameter_settings.html#ga58cddc825e786fda9e19a8fd8b5879ca", null ],
          [ "canParamSwapEntries", "group___named_parameter_settings.html#gaa4e7c274507842195ee77d1a99afbd43", null ]
        ] ]
      ] ],
      [ "t-script", "group__t_script.html", [
        [ "Typedefs", "group__t_script.html", [
          [ "kvEnvHandle", "group__t_script.html#ga3c0245bcd16b3bf93bd855a2fc8764f0", null ]
        ] ],
        [ "Functions", "group__t_script.html", [
          [ "kvFileCopyFromDevice", "group__t_script.html#ga34a02902fcb3a66722f9abfa518156cd", null ],
          [ "kvFileCopyToDevice", "group__t_script.html#ga592f3c34c4c9617bfe79440ce6857817", null ],
          [ "kvFileDelete", "group__t_script.html#gad26449b2a950062a2295cb83283d09c8", null ],
          [ "kvFileGetCount", "group__t_script.html#ga1fdcf6f2e1a83cf5cc0c12406b013d9e", null ],
          [ "kvFileGetName", "group__t_script.html#gad0770d0c23d7ffe7e6f7ac7f3acb4ed9", null ],
          [ "kvFileGetSystemData", "group__t_script.html#ga6d074875340ff2559d5a5db24d06ac06", null ],
          [ "kvScriptEnvvarClose", "group__t_script.html#ga30f88cbfc588c801f8bf4c81c094875c", null ],
          [ "kvScriptEnvvarGetData", "group__t_script.html#ga5cbb37e43a2e24358c63295fedfe06a3", null ],
          [ "kvScriptEnvvarGetFloat", "group__t_script.html#gafee8ff7e33041bee5f523115aae7f59e", null ],
          [ "kvScriptEnvvarGetInt", "group__t_script.html#gacf9775ec635485786a4afb3cb77ce94e", null ],
          [ "kvScriptEnvvarOpen", "group__t_script.html#ga5c172435cce62359713bc759b6cbbe04", null ],
          [ "kvScriptEnvvarSetData", "group__t_script.html#ga69c47354ff6b8d45e2c1fede92d02ade", null ],
          [ "kvScriptEnvvarSetFloat", "group__t_script.html#ga0e1f89bb27cb2041643e9e97efd47839", null ],
          [ "kvScriptEnvvarSetInt", "group__t_script.html#gaef0cffb28882fa9a731cda884ea8332c", null ],
          [ "kvScriptGetText", "group__t_script.html#gab9c6a1fc7fd430bf101ee3fea7b9a3ac", null ],
          [ "kvScriptLoadFile", "group__t_script.html#ga836f264e247e16b3d4ea1a025597cef3", null ],
          [ "kvScriptLoadFileOnDevice", "group__t_script.html#ga4b94293f0c19729e8471e43365e8b535", null ],
          [ "kvScriptRequestText", "group__t_script.html#gaa32fac50302a1dc190753b2fe918213c", null ],
          [ "kvScriptSendEvent", "group__t_script.html#ga17a485eb7bd6f827272b1e5199d8e828", null ],
          [ "kvScriptStart", "group__t_script.html#ga18554bbb583f0c869f749b94464b7c18", null ],
          [ "kvScriptStatus", "group__t_script.html#gafd614d2af0782de6f59ff33fa7100c57", null ],
          [ "kvScriptStop", "group__t_script.html#gab354b2471f49116c042a7e07a09754d8", null ],
          [ "kvScriptUnload", "group__t_script.html#gafd6f526de1787883abcf6c135476366a", null ]
        ] ]
      ] ],
      [ "Obsolete API Reference", "group___obsolete.html", [
        [ "Defines", "group___obsolete.html", [
          [ "canCARD_AC2", "group___obsolete.html#ga001d5b5faa6b7cf763f8c7dc46145eb0", null ],
          [ "canCARD_ANY", "group___obsolete.html#ga4b64c1f94d2494322e58aed758699aee", null ],
          [ "canCARD_CANCARD", "group___obsolete.html#ga08220bf4990d9fa2ea8638f474805738", null ],
          [ "canCARD_ISACAN", "group___obsolete.html#ga02a364c07a477546ae6126b25789b4a4", null ],
          [ "canCARD_LAPCAN", "group___obsolete.html#gadf16112de350267f399b9c05f2e4dc0f", null ],
          [ "CANCARD_NEC72005", "group___obsolete.html#ga10ca79a83886db92d3e39d040c7692f5", null ],
          [ "canCARD_PCCAN", "group___obsolete.html#ga65cb4f34d3fa0e5bf1045b7d8beff8f3", null ],
          [ "canCARD_PCCAN_OEM", "group___obsolete.html#ga632ebe7918d7b5b17470a8951caa6ebe", null ],
          [ "canCHANNEL_ANY", "group___obsolete.html#gaee4c0efaad3f26cbe409d8dcb881211a", null ],
          [ "canCIRCSTAT_BUS_OFF", "group___obsolete.html#gad994912c4536903f28970014eee3c5f2", null ],
          [ "canCIRCSTAT_ERROR_PASSIVE", "group___obsolete.html#gafdf23342afd8e2b5b215e9099a1f1693", null ],
          [ "canCIRCSTAT_ERROR_WARNING", "group___obsolete.html#ga7c565661a9acce72058a7b719eb3ac6a", null ],
          [ "canCIRCUIT_ANY", "group___obsolete.html#gad3b717b2015acd51d71276be754a531f", null ],
          [ "canDISCARD_MESSAGE", "group___obsolete.html#ga48aba51976ac7ed6955b5f1b6e4d0d81", null ],
          [ "canERR_BUFOFL", "group___obsolete.html#ga40e79d6d9f7ab76ff14a008384c9b282", null ],
          [ "canERR_CARDCOMMFAILED", "group___obsolete.html#gada5f51751c8aadaa299a1a78837e2d90", null ],
          [ "canERR_MSGLOST", "group___obsolete.html#ga69c105a64ac6e002df1c2a9ceb11037b", null ],
          [ "canERR_OVERRUN", "group___obsolete.html#ga39d891a2c33b57b03fedc898c75fd5a7", null ],
          [ "canERR_REINIT", "group___obsolete.html#ga2a9bf8f2f84539bea261bace7f05ecae", null ],
          [ "canFlgACCEPT", "group___obsolete.html#gaecf642915bde354d18919ce81f1cd334", null ],
          [ "canFlgCODE", "group___obsolete.html#gab193293a42ee0d30017c313e437a14f7", null ],
          [ "canFlgMASK", "group___obsolete.html#gab42af8693277aea78bcaa557bc33fd38", null ],
          [ "canFlgREJECT", "group___obsolete.html#gad0f169d4007c3f56e4ca00a0c61010ce", null ],
          [ "CANID_METAMSG", "group___obsolete.html#gabb96160adc140e0969f26ff5441b2878", null ],
          [ "CANID_WILDCARD", "group___obsolete.html#gaa3b348ffd146640d6e6084e1d53d4157", null ],
          [ "canINVPULLDOWN", "group___obsolete.html#gab77a444a6d4ccc09caf9aa3ba32663a1", null ],
          [ "canINVPULLUP", "group___obsolete.html#ga0e5622d9f06f5abde9f963c9a85aaaaf", null ],
          [ "canINVPUSHPULL", "group___obsolete.html#ga6e158a4fe2ecfec1128ceea673544c77", null ],
          [ "canIOCTL_LOCAL_ECHO_OFF", "group___obsolete.html#ga20f09562378f9e0531c37c9a0d2ecaf1", null ],
          [ "canIOCTL_LOCAL_ECHO_ON", "group___obsolete.html#ga9948614d7b592c89a8c860de251337b5", null ],
          [ "canMSG_STATUS", "group___obsolete.html#ga8c5f48d3ea2c97e5940544a58b12f9d8", null ],
          [ "canOFF", "group___obsolete.html#ga617b014a43ee96f2606f3c12553e3eb7", null ],
          [ "canPULLDOWN", "group___obsolete.html#gaa1da0634f0eeed650569e8a5b5ce1859", null ],
          [ "canPULLUP", "group___obsolete.html#ga9275fa9361820f5d65332519a55435da", null ],
          [ "canPUSHPULL", "group___obsolete.html#ga737411dc9c47ef015221766d3a2e76e0", null ],
          [ "canRETAIN_MESSAGE", "group___obsolete.html#ga8a72d54036ad69f35a2bc25815482572", null ],
          [ "canSLOW_MODE", "group___obsolete.html#gaf3568376c75640ee4ef87aa760c73d68", null ],
          [ "canSTAT_INACTIVE", "group___obsolete.html#ga06fb192e046b16bd077ec8a92104d65f", null ],
          [ "canSTICKY_ACK_ERROR", "group___obsolete.html#ga8030c90631adbc8f0d956619f422e568", null ],
          [ "canSTICKY_BIT0_ERROR", "group___obsolete.html#ga5ae21ef82de862e96009b54f9760be0b", null ],
          [ "canSTICKY_BIT1_ERROR", "group___obsolete.html#gaad97eb3d6da6c032ad6a089c344b7866", null ],
          [ "canSTICKY_CRC_ERROR", "group___obsolete.html#ga65857c22156421ee5702cf0d437e16a8", null ],
          [ "canSTICKY_FORM_ERROR", "group___obsolete.html#gade9ddc2154553f218bcc5ed27ea96d6c", null ],
          [ "canSTICKY_HW_OVERRUN", "group___obsolete.html#gaf1d768287e551593a1e2ad56a58febdd", null ],
          [ "canSTICKY_STUFF_ERROR", "group___obsolete.html#ga0d33e6325f41149efc7c63a0811e55bf", null ],
          [ "canSTICKY_SW_OVERRUN", "group___obsolete.html#ga8de86e1d8e2eabe18c3356b3de2d1104", null ],
          [ "canTRISTATE", "group___obsolete.html#gaa87e5c3de3aeb3c182b5b6f887add48b", null ],
          [ "canWANT_ACTIONS", "group___obsolete.html#ga5ce1872dbf11af861f47b6dce50b0291", null ],
          [ "canWANT_ERROR_COUNTERS", "group___obsolete.html#ga75968fe478206eee0007542219d8c34d", null ],
          [ "canWANT_EXCLUSIVE", "group___obsolete.html#ga48cd7c2e8ed2e7bf39d3524f7a4294d6", null ],
          [ "canWANT_EXTENDED", "group___obsolete.html#gab146450ad0889edc72e3d59dea710a17", null ],
          [ "canWANT_OWN_BUFFERS", "group___obsolete.html#ga95fbe13f2afafbf4ffda3f4fb28b05a8", null ],
          [ "canWANT_VIRTUAL", "group___obsolete.html#ga568de577a456a8fda2722f1f01e4cdd5", null ],
          [ "CIRC_SJA1000", "group___obsolete.html#gae7e88220b602c64364707d7db4f79a5a", null ],
          [ "CIRC_VIRTUAL", "group___obsolete.html#ga517ed48749255b252de9ec72e66b4a1a", null ],
          [ "PCCAN_INTEL526", "group___obsolete.html#ga6f568221b0f99615dc9180ceef26a9a2", null ],
          [ "PCCAN_INTEL527", "group___obsolete.html#gabc1429917402cbacb9f560cf5c734cd8", null ],
          [ "PCCAN_PHILIPS", "group___obsolete.html#ga19a934f79a572bfd61a37d333ceb369e", null ]
        ] ],
        [ "Typedefs", "group___obsolete.html", [
          [ "canHWDescr", "group___obsolete.html#ga78f0ebc15a68ffc91e9f6c418ba68748", null ],
          [ "canMemoryAllocator", "group___obsolete.html#ga7cd02bee513c8bb29558bd78956f8c8a", null ],
          [ "canMemoryDeallocator", "group___obsolete.html#ga2a53fbdda7a62e4fa16076301c035d67", null ],
          [ "canSWDescr", "group___obsolete.html#ga70ab72b677cdf73c1f2eaff057dfb77d", null ]
        ] ],
        [ "Functions", "group___obsolete.html", [
          [ "canGetCircuits", "group___obsolete.html#ga33e880289af801e01aaa3d44aec32a5c", null ],
          [ "canInstallAction", "group___obsolete.html#gab8992255af9c02c75d646425a73eac26", null ],
          [ "canInstallOwnBuffer", "group___obsolete.html#gaf3d79256de520acbafae2442bb779956", null ],
          [ "canLocateHardware", "group___obsolete.html#ga060813d527eab3e196625921920eb2bc", null ],
          [ "canOpen", "group___obsolete.html#ga5449d5f7f71128442893d0e7804e610c", null ],
          [ "canUninstallAction", "group___obsolete.html#ga4430127078d9cbd9f6e750f9eb4a4715", null ],
          [ "canUninstallOwnBuffer", "group___obsolete.html#ga8094bf56752bd08cd550032e8b165cac", null ]
        ] ],
        [ "Data Structures", "group___obsolete.html", [
          [ "tagCanHWDescr", "structtag_can_h_w_descr.html", null ],
          [ "tagCanSWDescr", "structtag_can_s_w_descr.html", null ]
        ] ]
      ] ],
      [ "CAN Database", "group___c_a_n_d_b.html", [
        [ "Defines", "group___c_a_n_d_b.html", [
          [ "KVADB_DATABASE_J1939", "group___c_a_n_d_b.html#ga9537a62c44999b70c79253ee1271e128", null ],
          [ "KVADB_MESSAGE_EXT", "group___c_a_n_d_b.html#gacb793e70d95b7daf6045c6dd9cc8792d", null ],
          [ "KVADB_MESSAGE_J1939", "group___c_a_n_d_b.html#ga0cb969b5cbf74422ee7064b6b8a355f7", null ],
          [ "KVADB_MESSAGE_WAKEUP", "group___c_a_n_d_b.html#ga796f3e3f05590caf5c6e7988ee0cd11e", null ],
          [ "KVADB_MUX_INDEPENDENT", "group___c_a_n_d_b.html#ga1d99a6637fef6f787f72765ba216b24d", null ],
          [ "KVADB_MUX_SIGNAL", "group___c_a_n_d_b.html#gaad29b7ca1fc896cc0036c26315d2b2ab", null ]
        ] ],
        [ "Typedefs", "group___c_a_n_d_b.html", [
          [ "KvaDbAttributeDefHnd", "group___c_a_n_d_b.html#ga4be0bd27b01ad1ef6e1117369416e7d6", null ],
          [ "KvaDbAttributeHnd", "group___c_a_n_d_b.html#ga9cddd35b77cdc51def41e560f0d01a5e", null ],
          [ "KvaDbHnd", "group___c_a_n_d_b.html#ga0ab6b252bb2dbf1312bd48208954e67b", null ],
          [ "KvaDbMessageHnd", "group___c_a_n_d_b.html#ga561c9270625ed9b7a4bc32edaab72227", null ],
          [ "KvaDbNodeHnd", "group___c_a_n_d_b.html#gadb7f65c8a757705c653045957266beb4", null ],
          [ "KvaDbSignalHnd", "group___c_a_n_d_b.html#gaa41cb518eea5c637f18eda0affa4e011", null ]
        ] ],
        [ "Enumerations", "group___c_a_n_d_b.html", [
          [ "KvaDbAttributeOwner", "group___c_a_n_d_b.html#ga486155dbae03cc008297edad213339d0", null ],
          [ "KvaDbAttributeType", "group___c_a_n_d_b.html#ga097f44c9d7fcb1cd04d12ff5d0f2a133", null ],
          [ "KvaDbSignalEncoding", "group___c_a_n_d_b.html#gad67767865a1ea13724d931f94d6eeee4", null ],
          [ "KvaDbSignalType", "group___c_a_n_d_b.html#gaca4f6042ed5df050dab2ff4278fc7270", null ],
          [ "KvaDbStatus", "group___c_a_n_d_b.html#ga2f504ec74e40048f49ed23d630528d57", null ]
        ] ],
        [ "Functions", "group___c_a_n_d_b.html", [
          [ "kvaDbAddFile", "group___c_a_n_d_b.html#ga5b519b0fee0fb480488a5a5c628c863a", null ],
          [ "kvaDbAddMsg", "group___c_a_n_d_b.html#ga20409dc07a8fa5f38cfd2e54f98e5748", null ],
          [ "kvaDbAddMsgAttribute", "group___c_a_n_d_b.html#ga895fc58f6fa4ac946e4bb519a5348b59", null ],
          [ "kvaDbAddNode", "group___c_a_n_d_b.html#ga5a300cc7269113c859289b37dbbcb6f2", null ],
          [ "kvaDbAddNodeAttribute", "group___c_a_n_d_b.html#ga572aececa809758b5be2a9281dc51c5b", null ],
          [ "kvaDbAddReceiveNodeToSignal", "group___c_a_n_d_b.html#gac5a5eb07e09efb0edfd3cd87790d7449", null ],
          [ "kvaDbAddSignal", "group___c_a_n_d_b.html#gabbbad3a12d611acbd969734481fcc48c", null ],
          [ "kvaDbAddSignalAttribute", "group___c_a_n_d_b.html#gaff8d4a4fabf98a9da8327baa8f0aed25", null ],
          [ "kvaDbClose", "group___c_a_n_d_b.html#ga08c85db8a33c4dcdb9d1114b72ab7c30", null ],
          [ "kvaDbCreate", "group___c_a_n_d_b.html#ga0da72bb21d2664d6443f7b3349ec9df5", null ],
          [ "kvaDbDeleteMsg", "group___c_a_n_d_b.html#ga35653db199de9237996e708ef9cfd7c1", null ],
          [ "kvaDbDeleteMsgAttribute", "group___c_a_n_d_b.html#ga537998cc1fd0bc2e8f2960d75f53b672", null ],
          [ "kvaDbDeleteNode", "group___c_a_n_d_b.html#ga5f7a0c98cd20d4f4e79a1edfd0c5e3a5", null ],
          [ "kvaDbDeleteNodeAttribute", "group___c_a_n_d_b.html#gaf8b92b8e9118412510779b3ed39472e9", null ],
          [ "kvaDbDeleteSignal", "group___c_a_n_d_b.html#gac92ad44609f7e08b21b00c1517643e59", null ],
          [ "kvaDbDeleteSignalAttribute", "group___c_a_n_d_b.html#gacb468194b6832ea1165bd9b257bba92a", null ],
          [ "kvaDbGetAttributeDefinitionByName", "group___c_a_n_d_b.html#ga8c510183f27c531345a8753cbd8d95cc", null ],
          [ "kvaDbGetAttributeDefinitionEnumeration", "group___c_a_n_d_b.html#ga6f1a812eee5818210df7d3e1c1bca0af", null ],
          [ "kvaDbGetAttributeDefinitionFloat", "group___c_a_n_d_b.html#ga7e7561c732e73ff957e727e977b19af2", null ],
          [ "kvaDbGetAttributeDefinitionInt", "group___c_a_n_d_b.html#ga5e96f0b80e03eb21c47d19217e6aef9e", null ],
          [ "kvaDbGetAttributeDefinitionName", "group___c_a_n_d_b.html#ga545d6689c298cad89dcf321cb5dedbde", null ],
          [ "kvaDbGetAttributeDefinitionOwner", "group___c_a_n_d_b.html#ga2043fabdf96aa79b5727497ba9b823dc", null ],
          [ "kvaDbGetAttributeDefinitionString", "group___c_a_n_d_b.html#ga39d43276147a73ff355119fa9356ec56", null ],
          [ "kvaDbGetAttributeDefinitionType", "group___c_a_n_d_b.html#gab05bb9b7e8f31ccdd09e4898abc31ae9", null ],
          [ "kvaDbGetAttributeName", "group___c_a_n_d_b.html#ga9b4c1106c5ed4531925e436d3d4034dd", null ],
          [ "kvaDbGetAttributeType", "group___c_a_n_d_b.html#ga3f0b81f7b4ee457a7002ccd3af251978", null ],
          [ "kvaDbGetAttributeValueEnumeration", "group___c_a_n_d_b.html#ga7578b036a1b304874e8d61eaea5252e3", null ],
          [ "kvaDbGetAttributeValueFloat", "group___c_a_n_d_b.html#gaf24b0727ee677167cd371b4ac2abbf16", null ],
          [ "kvaDbGetAttributeValueInt", "group___c_a_n_d_b.html#gacfa89a142224438951f501e730de1408", null ],
          [ "kvaDbGetAttributeValueString", "group___c_a_n_d_b.html#ga382dbefe56378b9e23bead0d914097e3", null ],
          [ "kvaDbGetFirstAttributeDefinition", "group___c_a_n_d_b.html#gae00e9a1fcede7194c455b563ef9b88a6", null ],
          [ "kvaDbGetFirstMsg", "group___c_a_n_d_b.html#ga860fbe484bbe5722c5141e8d73d51b81", null ],
          [ "kvaDbGetFirstMsgAttribute", "group___c_a_n_d_b.html#ga2b5c7bd301a1b8199fdc77c9aa5aceb0", null ],
          [ "kvaDbGetFirstNode", "group___c_a_n_d_b.html#ga9f10f9f99a4256478b35b4b97d569080", null ],
          [ "kvaDbGetFirstNodeAttribute", "group___c_a_n_d_b.html#gad6991dab90e666401fe6a59cf47e8a67", null ],
          [ "kvaDbGetFirstSignal", "group___c_a_n_d_b.html#gaeec680d3d20bddb57dd09389faacba9e", null ],
          [ "kvaDbGetFirstSignalAttribute", "group___c_a_n_d_b.html#ga1698bce319bf3594798a940e1339235e", null ],
          [ "kvaDbGetFlags", "group___c_a_n_d_b.html#ga04b35b1f5416157cb633cf7c44df396e", null ],
          [ "kvaDbGetMsgAttributeByName", "group___c_a_n_d_b.html#ga8dc2f474a745af37d128a7cca676fa4d", null ],
          [ "kvaDbGetMsgById", "group___c_a_n_d_b.html#ga732d691ed8ead650e4a49d18c8f7ffa2", null ],
          [ "kvaDbGetMsgByName", "group___c_a_n_d_b.html#ga9685fdb33257ac28e4cd989cfe8ca154", null ],
          [ "kvaDbGetMsgComment", "group___c_a_n_d_b.html#gace75dd206cd50883de777ed1d8051e1b", null ],
          [ "kvaDbGetMsgDlc", "group___c_a_n_d_b.html#gaad8505adb65a9f91a646951136456404", null ],
          [ "kvaDbGetMsgId", "group___c_a_n_d_b.html#gad38351a6992901219de951400c681974", null ],
          [ "kvaDbGetMsgMux", "group___c_a_n_d_b.html#ga038b6cd47cd5aa6f3d7e8e26808943a1", null ],
          [ "kvaDbGetMsgName", "group___c_a_n_d_b.html#ga194badc7e10d889df38a0f4eb763b5e6", null ],
          [ "kvaDbGetMsgQualifiedName", "group___c_a_n_d_b.html#gad34b31d9be199e8b7ac2d7d3dcab8f1e", null ],
          [ "kvaDbGetNextAttribute", "group___c_a_n_d_b.html#gad96bb66407d3d76c157ff37a515b58a7", null ],
          [ "kvaDbGetNextAttributeDefinition", "group___c_a_n_d_b.html#ga1d7596e7ab7eb506c53121a13f8dc63f", null ],
          [ "kvaDbGetNextMsg", "group___c_a_n_d_b.html#ga0146dd4ddf2c39bfdc3b93c29fe85b32", null ],
          [ "kvaDbGetNextNode", "group___c_a_n_d_b.html#ga0c53e72a3905ce374bb84a90e2d4533d", null ],
          [ "kvaDbGetNextSignal", "group___c_a_n_d_b.html#ga98c181ec06d6975556d2f893ec353b90", null ],
          [ "kvaDbGetNodeAttributeByName", "group___c_a_n_d_b.html#ga25ce4037a1db7a26e3a1f83da0040e76", null ],
          [ "kvaDbGetNodeAttributeIntByName", "group___c_a_n_d_b.html#gaafc126902093e5f00650035158644552", null ],
          [ "kvaDbGetNodeByName", "group___c_a_n_d_b.html#gaeadd31aaad178cda86c4ee029833fabc", null ],
          [ "kvaDbGetNodeName", "group___c_a_n_d_b.html#gade33a3dcdb4b3a61d35ac9b3b5cac6c5", null ],
          [ "kvaDbGetSignalAttributeByName", "group___c_a_n_d_b.html#ga150783801c9a7044f880f380199aff20", null ],
          [ "kvaDbGetSignalByName", "group___c_a_n_d_b.html#ga1f735b50e369c784901abc3ea436fba9", null ],
          [ "kvaDbGetSignalComment", "group___c_a_n_d_b.html#gadd24017befa2f40a86c84792fe176b52", null ],
          [ "kvaDbGetSignalEncoding", "group___c_a_n_d_b.html#ga1f399fd6ccee89e0a0c4f5df1324311b", null ],
          [ "kvaDbGetSignalMode", "group___c_a_n_d_b.html#ga6bc81e8bbce9f58b4dd113d4501c7a40", null ],
          [ "kvaDbGetSignalName", "group___c_a_n_d_b.html#ga1789980c0ede9307c77ecc265be94539", null ],
          [ "kvaDbGetSignalPresentationType", "group___c_a_n_d_b.html#gabd4ffb9b527127a9c144570ce63ae628", null ],
          [ "kvaDbGetSignalQualifiedName", "group___c_a_n_d_b.html#ga60dabd749ad9113ecff2cf4d6fc4df62", null ],
          [ "kvaDbGetSignalRepresentationType", "group___c_a_n_d_b.html#ga0bb3a9d21b17499ebd838b9d21114d53", null ],
          [ "kvaDbGetSignalUnit", "group___c_a_n_d_b.html#ga1b531b74cc568105f7ed3fbaefbcb7b4", null ],
          [ "kvaDbGetSignalValueFloat", "group___c_a_n_d_b.html#gaa55f93eb1866e1786e66be587abf1b6f", null ],
          [ "kvaDbGetSignalValueInteger", "group___c_a_n_d_b.html#ga929e36e4b5b88d6c4db67c50f0b6f9e9", null ],
          [ "kvaDbGetSignalValueLimits", "group___c_a_n_d_b.html#gac0d9f8909c721b79b0c0e213fc22e607", null ],
          [ "kvaDbGetSignalValueScaling", "group___c_a_n_d_b.html#gac592e48b7618d40d778698a5c21ed14d", null ],
          [ "kvaDbGetSignalValueSize", "group___c_a_n_d_b.html#ga81ca4318029cefe8ecf5df6e5c237b5e", null ],
          [ "kvaDbOpen", "group___c_a_n_d_b.html#gacbcd92e8da46f1b756c72d25ab92d240", null ],
          [ "kvaDbReadFile", "group___c_a_n_d_b.html#gaadd6d76a4a37fce5dacddc973951e8c8", null ],
          [ "kvaDbRemoveReceiveNodeFromSignal", "group___c_a_n_d_b.html#ga9cbe7fe2db516ac4747d0d5c6f5a51f0", null ],
          [ "kvaDbSetAttributeValueEnumeration", "group___c_a_n_d_b.html#gab7122a4522c858710acff0c7c6b942a3", null ],
          [ "kvaDbSetAttributeValueFloat", "group___c_a_n_d_b.html#ga60903e8eb00b40da48155f4d0e58d961", null ],
          [ "kvaDbSetAttributeValueInt", "group___c_a_n_d_b.html#gafbebcc3892941d49afc6150dd74f6935", null ],
          [ "kvaDbSetAttributeValueString", "group___c_a_n_d_b.html#ga7105f77e536fd5b3684dc1c555f0a733", null ],
          [ "kvaDbSetDummyFileName", "group___c_a_n_d_b.html#ga927869d77b7bde7a2b0384dc6ec8c759", null ],
          [ "kvaDbSetFlags", "group___c_a_n_d_b.html#ga0749d01aa354efde03f7141a59dc9de4", null ],
          [ "kvaDbSetMsgComment", "group___c_a_n_d_b.html#ga6a9bd277edbb0617de75553dd9aa21fa", null ],
          [ "kvaDbSetMsgDlc", "group___c_a_n_d_b.html#ga4adb841c585acfacdb73c5836a7c5b7d", null ],
          [ "kvaDbSetMsgId", "group___c_a_n_d_b.html#ga6b607012a7889df9b00f032aee6959ff", null ],
          [ "kvaDbSetMsgName", "group___c_a_n_d_b.html#gab0420983b735501899087eef7b127ccd", null ],
          [ "kvaDbSetNodeComment", "group___c_a_n_d_b.html#ga756689d7c8309109a7dfc83378383747", null ],
          [ "kvaDbSetNodeName", "group___c_a_n_d_b.html#ga11e891be4facd6e3f5ec02c6f0e313bd", null ],
          [ "kvaDbSetSignalComment", "group___c_a_n_d_b.html#ga124f0345c198a4f2c5a79c1620fba6a7", null ],
          [ "kvaDbSetSignalEncoding", "group___c_a_n_d_b.html#ga692bc09e34328197d5061cdb521c6c3f", null ],
          [ "kvaDbSetSignalMode", "group___c_a_n_d_b.html#gaed56ea9b1c0a83ed18a9609d0de8436c", null ],
          [ "kvaDbSetSignalName", "group___c_a_n_d_b.html#ga43c3ac08f5a5114b1495b073d285df06", null ],
          [ "kvaDbSetSignalRepresentationType", "group___c_a_n_d_b.html#gab9a22491498bd216717e9edf627b694d", null ],
          [ "kvaDbSetSignalUnit", "group___c_a_n_d_b.html#gabf8723b14dafc4597cd68d72a0608884", null ],
          [ "kvaDbSetSignalValueLimits", "group___c_a_n_d_b.html#ga3bfdb0480993002989f6f73b84768f9c", null ],
          [ "kvaDbSetSignalValueScaling", "group___c_a_n_d_b.html#ga3a01b63f3b3a413d008bdcb85778034f", null ],
          [ "kvaDbSetSignalValueSize", "group___c_a_n_d_b.html#ga734770b9b425260f1f9bb4dc5a886aaf", null ],
          [ "kvaDbStoreSignalValuePhys", "group___c_a_n_d_b.html#gacb39e188fc39f6819c64913c62abc664", null ],
          [ "kvaDbStoreSignalValueRaw", "group___c_a_n_d_b.html#gaef1ef6172b380caeb476ecb9784566a3", null ],
          [ "kvaDbWriteFile", "group___c_a_n_d_b.html#gabf1db33bc6778e2f77ab1b66e8f743e9", null ]
        ] ]
      ] ],
      [ "LIN", "group___l_i_n.html", [
        [ "Defines", "group___l_i_n.html", [
          [ "CompilerAssert", "group___l_i_n.html#ga147705d4bcf2fbb603385ec0dea71592", null ],
          [ "LIN_BIT_ERROR", "group___l_i_n.html#ga719cb4b7b29a67803d34ec60ea5e8a4d", null ],
          [ "LIN_CSUM_ERROR", "group___l_i_n.html#gaf7386e03bb99718fd308013450641cce", null ],
          [ "LIN_ENHANCED_CHECKSUM", "group___l_i_n.html#ga937225a25c3c24efabf7c8438ccecd09", null ],
          [ "LIN_MASTER", "group___l_i_n.html#gaddf7881b12723497542ff0f66222c46e", null ],
          [ "LIN_MSG_DISTURB_CSUM", "group___l_i_n.html#ga479885d0466fcaff2cb80dedd09a7805", null ],
          [ "LIN_MSG_DISTURB_PARITY", "group___l_i_n.html#gad4e1ec16e25ca05d694d1faff1ebf147", null ],
          [ "LIN_MSG_USE_ENHANCED_PARITY", "group___l_i_n.html#ga8c2ab5dd117f814cef07f6b072aaafc9", null ],
          [ "LIN_MSG_USE_STANDARD_PARITY", "group___l_i_n.html#ga88ace2b1c8f8f6ed08714fc8725a03f8", null ],
          [ "LIN_NODATA", "group___l_i_n.html#gaa7796bf62c2772d49bd5572e7302f55e", null ],
          [ "LIN_PARITY_ERROR", "group___l_i_n.html#ga79d31160f0025e7c6c7fe6d5cb843847", null ],
          [ "LIN_RX", "group___l_i_n.html#ga8a77e3db8950ff23e2a154d3c347f307", null ],
          [ "LIN_SLAVE", "group___l_i_n.html#ga9b19af88006130b3220a4ecb57cd4e0b", null ],
          [ "LIN_SYNCH_ERROR", "group___l_i_n.html#gad8f162919711144a9cc1ae398f569e53", null ],
          [ "LIN_TX", "group___l_i_n.html#gaa71a0b1071a3246b40ed830f32ed43ce", null ],
          [ "LIN_VARIABLE_DLC", "group___l_i_n.html#ga2edd31e15abb5f7cb8dd213fd707dfff", null ],
          [ "LIN_WAKEUP_FRAME", "group___l_i_n.html#ga1837b69bf93680cfe775253ebb01e5ef", null ],
          [ "LINERROR", "group___l_i_n.html#gab873580aa6b650d641cc2439b96a118a", null ],
          [ "linINVALID_HANDLE", "group___l_i_n.html#gaf080de594ae6f3a531e9b530577e9ebe", null ],
          [ "LINLIBAPI", "group___l_i_n.html#ga4817ac11ca69f5237588c0a3f422bcdb", null ]
        ] ],
        [ "Typedefs", "group___l_i_n.html", [
          [ "LinHandle", "group___l_i_n.html#ga759b2696d97bd97008d8df007d9ac44a", null ]
        ] ],
        [ "Enumerations", "group___l_i_n.html", [
          [ "LinStatus", "group___l_i_n.html#ga7a5ecfd2846ddd76cd49fb4edec7fc14", null ]
        ] ],
        [ "Functions", "group___l_i_n.html", [
          [ "linBusOff", "group___l_i_n.html#ga051ffc0c24d6322825cbc8ff21e50744", null ],
          [ "linBusOn", "group___l_i_n.html#ga79ab73655c1749ad9fe2b784885e2dd9", null ],
          [ "linClearMessage", "group___l_i_n.html#ga905647480dd89a7225e4b8ae0d82cb92", null ],
          [ "linClose", "group___l_i_n.html#ga5d8cb59baccdefc9e772ad34c01c596f", null ],
          [ "linGetCanHandle", "group___l_i_n.html#gadf904a2ba0101ac6dc622b6035cf0f5f", null ],
          [ "linGetFirmwareVersion", "group___l_i_n.html#gafa260028be850e70a99c1b0706679583", null ],
          [ "linGetTransceiverData", "group___l_i_n.html#ga95408cd6c8639514b4be8e188bd7b38a", null ],
          [ "linInitializeLibrary", "group___l_i_n.html#gaf47a1f1078f6b3919e2b2d9dfd559d8b", null ],
          [ "linOpenChannel", "group___l_i_n.html#ga040336f8176a10cb9578b47c42baef6b", null ],
          [ "linReadMessage", "group___l_i_n.html#gaca2d874c870f16c11a4e8e158817d8bf", null ],
          [ "linReadMessageWait", "group___l_i_n.html#gaa2f729a931bf644ce62b373ab7414250", null ],
          [ "linReadTimer", "group___l_i_n.html#ga8af35ecbb1aca56baed27990f3d43d4b", null ],
          [ "linRequestMessage", "group___l_i_n.html#ga068419b8b624d8918720a8907c4f9274", null ],
          [ "linSetBitrate", "group___l_i_n.html#ga77e1463234ee6c67a71a2ab57f578b7f", null ],
          [ "linSetupIllegalMessage", "group___l_i_n.html#ga1c89e03300af644cee54861f92ae567e", null ],
          [ "linSetupLIN", "group___l_i_n.html#ga911287175a2ca5574a50d17b698b6d9d", null ],
          [ "linUpdateMessage", "group___l_i_n.html#ga5bf84820248e95fde2718fa46304a5a5", null ],
          [ "linWriteMessage", "group___l_i_n.html#gac012f34a621bc885bd582398c3d5d175", null ],
          [ "linWriteSync", "group___l_i_n.html#ga1bd437b46f5923f05905c43cd4a1617a", null ],
          [ "linWriteWakeup", "group___l_i_n.html#ga4ba0a5256a785f3cc67a5e661837223e", null ]
        ] ],
        [ "Data Structures", "group___l_i_n.html", [
          [ "LinMessageInfo", "struct_lin_message_info.html", null ]
        ] ]
      ] ],
      [ "J1587", "group___j1587.html", [
        [ "Defines", "group___j1587.html", [
          [ "canTRANSCEIVER_TYPE_LINX_J1708", "group___j1587.html#gacb5d029625550dbcbc1163770fdd3cfc", null ],
          [ "canTRANSCEIVER_TYPE_LINX_K", "group___j1587.html#ga451986925bbb397794b9c8c6a29aed57", null ],
          [ "canTRANSCEIVER_TYPE_LINX_LIN", "group___j1587.html#ga24636beba2413b67e5b733d52340917d", null ],
          [ "canTRANSCEIVER_TYPE_LINX_LS", "group___j1587.html#gaf5482786e5c5cebba339b0cb9605350d", null ],
          [ "canTRANSCEIVER_TYPE_LINX_SWC", "group___j1587.html#ga1256b58f6defda7e909634eaa2ae73a9", null ],
          [ "EEPROM_OP_MODE_J1587_NODE", "group___j1587.html#ga456c8f48df26f7d02f33cb59bbb3df3d", null ],
          [ "EEPROM_OP_MODE_J1587_NORMAL", "group___j1587.html#ga0ab00a1148379ccb821facdd21c3c801", null ],
          [ "EEPROM_OP_MODE_NONE", "group___j1587.html#ga795961a604e9d9dcf3c266e93e15d0ff", null ],
          [ "J1587_INTER_CHAR_DELAY_MASK", "group___j1587.html#ga3e63352ccb996497680e1aa8ecfb2a60", null ],
          [ "J1587_NODE", "group___j1587.html#ga0e2465d8aad0e88488865341e475f56b", null ],
          [ "J1587_NORMAL", "group___j1587.html#gaeabd9249460f605a472544e588b60e9d", null ],
          [ "J1587_READ", "group___j1587.html#ga3cf6902604f41ab1f53a9e2a7829479f", null ],
          [ "J1587_REPORT_BAD_CHECKSUM", "group___j1587.html#gaf6aa113a7761679653f858eaa3035530", null ],
          [ "J1587_REPORT_CHAR_DELAY", "group___j1587.html#gab5c3ec5b8779c2fcc9d1afb14719f35f", null ],
          [ "J1587_REPORT_FRAME_DELAY", "group___j1587.html#ga9ecfca8f9ba61ac6dae21a08742f7dad", null ],
          [ "J1587_WRITE", "group___j1587.html#ga35f838abd9920afbe5791f1fda61300f", null ],
          [ "j1587FLAG_BYTEDELAY", "group___j1587.html#ga974fb1029705a4d382311856c21d8283", null ],
          [ "j1587FLAG_CHECKSUM", "group___j1587.html#ga8232022e95385fb0d272fadf8f5a1def", null ],
          [ "j1587FLAG_FRAMEDELAY", "group___j1587.html#ga967985573ce99af353c458e0d5f0c965", null ],
          [ "j1587FLAG_OVERRUN", "group___j1587.html#ga2e63ae718dcdcb331d1ccf3913f07dfe", null ],
          [ "j1587FLAG_STOPBIT", "group___j1587.html#ga5173400e2d86e27cb2dc0259f21e532c", null ],
          [ "j1587INVALID_HANDLE", "group___j1587.html#ga0d4dbf30b8bc71293ab597060674c0bc", null ],
          [ "J1587LIB_VERSION", "group___j1587.html#gadea67c0976177bae91ebf25e85023555", null ]
        ] ],
        [ "Typedefs", "group___j1587.html", [
          [ "J1587Handle", "group___j1587.html#ga50c70ee0d10dd0f5b157972ebe3aa372", null ]
        ] ],
        [ "Enumerations", "group___j1587.html", [
          [ "J1587Status", "group___j1587.html#gaf53b99d641e8f580bd6d82dddf25044e", null ]
        ] ],
        [ "Functions", "group___j1587.html", [
          [ "j1587BusOff", "group___j1587.html#ga0dafc22cc3147bf68a3502d643851ace", null ],
          [ "j1587BusOn", "group___j1587.html#gaf730fab726c0e5a524af0b843bfef15f", null ],
          [ "j1587Close", "group___j1587.html#gab22ee2c5a967c611c0ebf0a2b69d5fb3", null ],
          [ "j1587Configure", "group___j1587.html#gab0405005b58c5c1dc30b840c5e50ce75", null ],
          [ "j1587GetCanHandle", "group___j1587.html#ga704d965b5965d429405aeca53f79e062", null ],
          [ "j1587GetFirmwareVersion", "group___j1587.html#ga6f15d30b607348e2d2638d4d6cbc05d2", null ],
          [ "j1587InitializeLibrary", "group___j1587.html#ga05e527ed5611a37875494f18284f3342", null ],
          [ "j1587OpenChannel", "group___j1587.html#gaa21714de8be1af79afd7d56d38d4b4fe", null ],
          [ "j1587ReadMessageWait", "group___j1587.html#ga4347327b367910f5a777c3f054115f39", null ],
          [ "j1587ReadTimer", "group___j1587.html#gae9d6fdd6b254c2e9a3d28deebb256518", null ],
          [ "j1587SetBitrate", "group___j1587.html#ga5d56ee062e2c8461d45e55d1b93b7215", null ],
          [ "j1587WriteMessageWait", "group___j1587.html#ga69f23061d70b00e6b4913f5170dc10b9", null ],
          [ "j1587WriteSync", "group___j1587.html#gad32ad5a4b572941c695d24665065a30d", null ]
        ] ],
        [ "Data Structures", "group___j1587.html", [
          [ "J1587MessageInfo", "struct_j1587_message_info.html", null ]
        ] ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.html", [
      [ "canBusStatistics_s", "structcan_bus_statistics__s.html", null ],
      [ "canUserIoPortData", "structcan_user_io_port_data.html", null ],
      [ "J1587MessageInfo", "struct_j1587_message_info.html", null ],
      [ "kvTimeDomainData_s", "structkv_time_domain_data__s.html", null ],
      [ "LinMessageInfo", "struct_lin_message_info.html", null ],
      [ "tagCanHWDescr", "structtag_can_h_w_descr.html", null ],
      [ "tagCanSWDescr", "structtag_can_s_w_descr.html", null ]
    ] ],
    [ "Data Structure Index", "classes.html", null ],
    [ "Data Fields", "functions.html", null ],
    [ "File List", "files.html", [
      [ "canlib.h", "canlib_8h.html", null ],
      [ "canstat.h", "canstat_8h.html", null ],
      [ "j1587lib.h", "j1587lib_8h.html", null ],
      [ "kvaDBlib.h", "kva_d_blib_8h.html", null ],
      [ "linlib.h", "linlib_8h.html", null ],
      [ "obsolete.h", "obsolete_8h.html", null ]
    ] ],
    [ "Examples", "examples.html", [
      [ "candb_sample.c", "candb_sample_8c-example.html", null ],
      [ "candemo.cpp", "candemo_8cpp-example.html", null ],
      [ "candump.c", "candump_8c-example.html", null ],
      [ "canecho.c", "canecho_8c-example.html", null ],
      [ "channeldata.c", "channeldata_8c-example.html", null ],
      [ "CLRcandump.cpp", "_c_l_rcandump_8cpp-example.html", null ],
      [ "envvar.c", "envvar_8c-example.html", null ],
      [ "gensig.c", "gensig_8c-example.html", null ],
      [ "j1587example.c", "j1587example_8c-example.html", null ],
      [ "JoyStick.cpp", "_joy_stick_8cpp-example.html", null ],
      [ "kvTimeStampTester.c", "kv_time_stamp_tester_8c-example.html", null ],
      [ "linTest.c", "lin_test_8c-example.html", null ],
      [ "read_customer_data.c", "read_customer_data_8c-example.html", null ],
      [ "swc.c", "swc_8c-example.html", null ],
      [ "thread.c", "thread_8c-example.html", null ],
      [ "tx.c", "tx_8c-example.html", null ]
    ] ],
    [ "Globals", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

